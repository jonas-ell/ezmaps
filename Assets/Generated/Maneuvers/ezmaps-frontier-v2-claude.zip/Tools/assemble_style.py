#!/usr/bin/env python3
"""Build a style from REAL provider bindings. Does not guess providers or credentials.
Usage: python Tools/assemble_style.py MapLibre/source-config.json output.style.json
"""
from pathlib import Path
import json,sys
def build(config,template):
    sources=config['sources'];bindings=config['bindings'];out=[]
    dem=bindings.get('dem',{})
    if not dem.get('enabled',True) or dem.get('source') not in sources:
        raise ValueError('Real DEM source is required for this look. Configure bindings.dem and sources; do not silently ship a flat fallback.')
    if sources[dem['source']].get('type')!='raster-dem':
        raise ValueError('The default relief layer requires a raster-dem source, not RGB aerial imagery.')
    for original in template:
        layer=json.loads(json.dumps(original));source=layer.get('source')
        if source:
            role=source.strip('_');binding=bindings.get(role)
            if not binding:raise ValueError('Missing binding: '+role)
            if not binding.get('enabled',True):continue
            actual=binding.get('source')
            if actual not in sources:raise ValueError('Missing real source for '+role)
            layer['source']=actual
            if sources[actual]['type']=='vector':
                if not binding.get('source_layer'):raise ValueError('Missing source_layer for '+role)
                layer['source-layer']=binding['source_layer']
            if binding.get('filter') is not None:layer['filter']=binding['filter']
        if config.get('mode')=='navigation':
            if layer['id'].endswith('-texture') or layer['id'] in ['fv2-grain','fv2-water-grain']:
                paint=layer['paint'];prop='background-opacity' if layer['type']=='background' else 'fill-opacity';paint[prop]=['*',paint[prop],.35]
            if layer['id']=='fv2-poi':layer['minzoom']=13
            if layer['id']=='fv2-player':layer['layout']['icon-size']=.9
        out.append(layer)
    style={'version':8,'name':config.get('name','Frontier V2'),'sprite':config['sprite'],'sources':sources,'layers':out,'metadata':{'frontier:note':'Generated from explicit provider bindings. Validate and render with the SDK pinned by the app.'}}
    if config.get('glyphs'):style['glyphs']=config['glyphs']
    return style
if __name__=='__main__':
    try:
        config=json.loads(Path(sys.argv[1]).read_text());template=json.loads((Path(__file__).resolve().parents[1]/'MapLibre/layers.template.json').read_text())
        result=build(config,template);Path(sys.argv[2]).write_text(json.dumps(result,indent=2));print('Style built. Now run the app SDK validator and render acceptance screenshots.')
    except (IndexError,KeyError,ValueError) as e:raise SystemExit('Cannot build style: '+str(e))
