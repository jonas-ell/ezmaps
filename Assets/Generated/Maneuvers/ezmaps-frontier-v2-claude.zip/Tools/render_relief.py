#!/usr/bin/env python3
"""Optional art-directed relief overlay from an elevation array (not a full tile server).
Input: finite 2D .npy elevations in meters on a square grid with known local meter spacing.
Output: transparent RGBA PNG, dark olive shade / chalk highlights. Requires numpy + Pillow.
Usage: python render_relief.py dem.npy relief.png --meters-per-pixel 10
For a tile pipeline supply a DEM with a 16+ pixel neighbor buffer and crop AFTER shading.
The caller must handle reprojection, latitude-dependent spacing, nodata, georeferencing,
water masking, source attribution and tile pyramids. No invented topography is added.
"""
import argparse
import numpy as np
from PIL import Image
def render(z,spacing):
    if z.ndim!=2 or min(z.shape)<3 or not np.isfinite(z).all() or spacing<=0:
        raise ValueError('Need finite 2D elevations, dimensions >=3 and positive meters per pixel')
    dy,dx=np.gradient(z.astype(float),spacing,spacing)
    nx=-dx;ny=dy;nz=np.ones_like(z);length=np.sqrt(nx*nx+ny*ny+nz*nz)
    # East=x, north=y. 315deg primary, weaker 270deg fill. Scalar illumination
    # is centered on flat terrain so flat land remains transparent.
    def light(az,alt):
        az=np.deg2rad(az);alt=np.deg2rad(alt)
        return (nx*np.sin(az)*np.cos(alt)+ny*np.cos(az)*np.cos(alt)+nz*np.sin(alt))/length-np.sin(alt)
    signal=.80*light(315,40)+.20*light(270,55)
    strength=np.where(signal<0,np.clip(-signal*245,0,150),np.clip(signal*320,0,170))
    rgb=np.where((signal>=0)[...,None],np.array([213,202,166]),np.array([65,72,44]))
    out=np.concatenate([np.broadcast_to(rgb,(*z.shape,3)),strength[...,None]],axis=2).astype(np.uint8)
    return Image.fromarray(out,'RGBA')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('dem');p.add_argument('output');p.add_argument('--meters-per-pixel',type=float,required=True);a=p.parse_args()
    render(np.load(a.dem,allow_pickle=False),a.meters_per_pixel).save(a.output)
