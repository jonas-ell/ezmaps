# Prüfung des V2-Pakets — 29.10.2026

## Durchgeführt

- 39 Produktionsassets, alle 156 PNG-Exporte vollständig geöffnet/dekodiert; RGBA, Sollmaße und echte transparente Pixel geprüft.
- Bei allen Sprites vollständig transparente Außenkanten geprüft. Die Exportpipeline setzt ausschließlich den äußersten Alpharand auf null, um minimale Resampling-Säume zu vermeiden.
- Gegenüberliegende Pixelkanten aller 20 Materialtextur-Exporte verglichen; Gleichheit bestätigt.
- Alle 34 Asset-SVGs als XML geöffnet.
- Alle 39 Einträge beider Atlanten pixelgenau mit Einzel-PNGs verglichen; Indexnamen, Bildgrenzen und Überschneidungen geprüft.
- JSON-Dateien geparst. Die Source-Bindungstests prüfen fehlenden DEM, Rollenauflösung und Navigationsmodus.
- Relief-Prototyp mit flachem DEM (transparente Ausgabe), variablem DEM (sichtbare Schattierung) und ungültigen Eingaben (Ablehnung) getestet.
- Übersicht aller 39 Assets visuell auf dem olivfarbenen Stilgrund betrachtet. Die beiden akzeptierten Zielbilder unverändert in das Paket übernommen.

## Noch offen im App-Projekt

- Rendering der Style-Bausteine mit echten Quellen in MapLibre Native.
- Offizielle Style-Schema-Validierung gegen die tatsächlich eingesetzte SDK-Version.
- Xcode-/Swift-Build, iPhone-/CarPlay-Simulator, Fahrzeugdisplay, Interaktions- und Kameratests.
- Visueller Vergleich echter Landschaft mit den Zielbildern, einschließlich unterschiedlicher Zoomstufen.
- Produktionsfähige Geodatenaufbereitung für den optionalen Relief-Prototyp.

Der Style-Assembler und das Relief-Werkzeug sind lokal getestete Integrationshilfen. Das ist keine Bestätigung, dass die App bereits genauso wie das Konzeptbild aussieht. `verification.json` enthält Prüfresultate und PNG-Prüfsummen, `asset-inventory.csv` die exakten Bildgrößen.

Herkunft: Die Zielbilder wurden zuvor mit dem eingebauten Bildgenerator erstellt und vom Nutzer als Richtung bestätigt. Piktogramme sind eigene Vektorgeometrie, V2 wurde ohne die alten Plaketten exportiert. Die Materialmuster sind deterministisch erzeugte periodische Overlays. Es wurden keine Spielsprites oder Spielkarten als Laufzeitassets extrahiert.
