# ezmaps Frontier V2

**Für Claude zuerst `START-HERE-CLAUDE.md` öffnen und beide Bilder unter `Reference/` ansehen.**

Dies ist das neue Asset- und Implementierungspaket für die akzeptierte Relief-/Feldkarten-Richtung. Es ersetzt die gestalterischen Vorgaben des verworfenen V1-Entwurfs.

- 39 Assets: 20 freistehende POIs, 8 Marker, 6 HUD-Elemente, 5 transparente periodische Materialien.
- 156 PNG-Exporte: @1x / @2x / @3x / 1024²-Master.
- 34 editierbare SVGs, plus MapLibre-Atlanten 1× und 2×.
- Zwei akzeptierte Zielbilder, HTML-Katalog, Manifeste und Dateiinventar.
- Konkreter Layer-Baustein, explizite Source-Konfiguration, Style-Assembler und optionaler Relief-Prototyp.
- Gestaltungsregeln, Abnahmekriterien und ehrlicher Prüfbericht.

Die Illustrationen definieren das Aussehen; sie sind keine georeferenzierten Kartenkacheln. Der gleiche Stil auf echten Orten benötigt echte Höhen- und Kartendaten. Keine fertige Xcode-/CarPlay-Integration und keine garantierte pixelidentische Renderer-Ausgabe enthalten.

`index.html` lokal öffnen. Assets in `Assets/Generated/FrontierV2/`. Für Quellen/DEM und die Integration siehe `MapLibre/README.md`.
