# Integration

1. `source-config.example.json` nach `source-config.json` kopieren. Echte Source-Definitionen eintragen, keine Beispiel-Keys erfinden.
2. Jede verwendete Bindung erhält `source`, bei Vektorkacheln `source_layer`, und einen passenden `filter`. Nicht vorhandene optionale Landnutzungsarten über `enabled:false` auslassen. Die DEM-Bindung ist für diesen Stil Pflicht.
3. `python Tools/assemble_style.py MapLibre/source-config.json frontier-v2.style.json` vom Paketstamm aus ausführen.
4. Den generierten Style mit der App-SDK-Version prüfen und rendern. Die mitgelieferte Vorlage ist nicht gegen einen realen Provider getestet.

Es werden keine Labels automatisch erzeugt: vorhandene echte Namen, Glyph-URL und Font-Stack aus dem Projekt übernehmen und sinnvolle Label-Layer ergänzen. Die Konfiguration kann `glyphs` weitergeben; `font_stack` dient als dokumentierte Projektangabe und wird nicht automatisch in Layer eingebaut.

`sprite` ist ein Dateistamm ohne Erweiterung. Die relative Beispiel-URL muss im App-Kontext korrekt aufgelöst oder durch eine erreichbare absolute URL ersetzt werden. Die Paare `frontier-v2.png/.json` und `frontier-v2@2x.png/.json` müssen zusammen ausgeliefert werden. Alternativ nach Style-Load PNGs über die native Bildregistrierung mit denselben IDs registrieren und den `sprite`-Eintrag entfernen. UIImage-Skalierung beim Laden von @2x/@3x explizit berücksichtigen. Alle Assets sind Originalfarben, `sdf:false`.

Runtime-GeoJSON:

| Source | Geometrie | Eigenschaften |
|---|---|---|
| fv2-route | LineString | echte berechnete Route |
| fv2-poi | Point | sprite: gültige fv2-poi-ID; priority: Zahl (kleiner zuerst) |
| fv2-friends | Point | sprite: gültige Freund-ID; bearing: Grad im Uhrzeigersinn ab Norden |
| fv2-destination | Point | tatsächliches Ziel; Icon hat Bottom-Anchor |
| fv2-player | Point | bearing: gültiger geglätteter Kurs |

Die gelieferten Runtime-Sources sind absichtlich leer. Sie dürfen nur mit tatsächlichen App-Daten befüllt werden. Freunde benötigen die vorhandene Freigabelogik und einen Umgang mit veralteten Positionen. Auswahlring bei Bedarf in separatem Layer über dem ausgewählten Freund zeichnen. Das Fadenkreuz ist ein festes UI-Overlay und gehört nicht in diese geografischen Sources.

Die Straße-/Brücke-/Tunnel-Reihenfolge, Wegklassen, Attributionen und Labels des tatsächlichen Providers müssen ergänzt werden. Der Assembler löst nur explizite Bindungen auf; er versteht keinen fremden Provider automatisch.
